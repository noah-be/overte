// Copyright 2026 Overte contributors
// SPDX-License-Identifier: Apache-2.0
// Genuine installed native Audio page plus explicitly browser-owned capture controls.
import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.3
import stylesUit 1.0
import controlsUit 1.0 as HifiControlsUit
Rectangle {
 id: root; color: '#252525'; property var browserState: ({version:1,active:false,controls:{echoCancellation:false,noiseSuppression:false,autoGainControl:false,inputGainPercent:false},settings:{echoCancellation:null,noiseSuppression:null,autoGainControl:null,inputGainPercent:null,inputGain:null}});
 HifiConstants { id: hifi; }
 property int browserUiEpoch:0;property bool browserReady:false;property string browserReason:'inactive';property bool awaiting:false;
 signal sendToScript(var message);
 function restoreControls(){echoControl.checked=Qt.binding(function(){return root.browserState.settings.echoCancellation===true;});noiseControl.checked=Qt.binding(function(){return root.browserState.settings.noiseSuppression===true;});agcControl.checked=Qt.binding(function(){return root.browserState.settings.autoGainControl===true;});gainControl.value=Qt.binding(function(){return root.browserState.settings.inputGainPercent===null?100:root.browserState.settings.inputGainPercent;});}
 function fromScript(message){if(message&&message.type==='browserCaptureScope'&&typeof message.epoch==='number'&&message.epoch%1===0&&message.epoch>=browserUiEpoch&&message.epoch>=1&&message.epoch<=2147483647){browserReady=false;awaiting=false;browserUiEpoch=message.epoch;if(message.active&&tabs.currentIndex===1)sendToScript({type:'browserCaptureReady',epoch:browserUiEpoch});return;}if(message&&message.type==='browserCaptureState'&&message.epoch===browserUiEpoch){browserReady=false;browserState=message.state;browserReason=message.reason||'ok';awaiting=false;restoreControls();browserReady=message.ready===true;}}
 function change(field,value){if(tabs.currentIndex===1&&browserUiEpoch>0&&browserReady&&!awaiting&&browserState.active&&browserState.controls[field]===true&&browserState.settings[field]!==value){awaiting=true;sendToScript({type:'browserCaptureChange',epoch:browserUiEpoch,field:field,value:value});}}
 ColumnLayout {anchors.fill:parent;spacing:8;
  TabBar {id:tabs;Layout.fillWidth:true;TabButton{text:'Native connection'}TabButton{text:'Browser microphone'}onCurrentIndexChanged:if(currentIndex===1)root.sendToScript({type:'browserCaptureReady',epoch:root.browserUiEpoch});}
  StackLayout {currentIndex:tabs.currentIndex;Layout.fillWidth:true;Layout.fillHeight:true;
   Item {Loader{id:nativeAudio;anchors.fill:parent;source:'qrc:/qml/hifi/audio/Audio.qml';}Connections{target:nativeAudio.item;ignoreUnknownSignals:true;function onSendToScript(message){root.sendToScript(message);}}Text{anchors.centerIn:parent;visible:nativeAudio.status===Loader.Error;color:'white';text:'The installed native Audio page could not be loaded.'}}
   Flickable {clip:true;contentWidth:width;contentHeight:settingsColumn.height;Column{id:settingsColumn;width:parent.width;spacing:18;
    Text{width:parent.width;wrapMode:Text.Wrap;color:'white';font.pixelSize:18;text:'Browser microphone processing'}
    Text{width:parent.width;wrapMode:Text.Wrap;color:'#cccccc';text:!root.browserReady?'Waiting for browser readback…':!root.browserState.active?'Enable your microphone in the browser to inspect and change capture settings.':root.awaiting?'Applying capture settings…':root.browserReason!=='ok'?'The browser did not apply this change ('+root.browserReason+').':'These controls affect your local browser microphone. Native mixer gains and device choices are separate.'}
    HifiControlsUit.Switch {id:echoControl;width:switchWidth;height:44;switchWidth:40;labelTextOn:'Echo Cancellation';checked:root.browserState.settings.echoCancellation===true;enabled:root.browserReady&&!root.awaiting&&root.browserState.controls.echoCancellation;onCheckedChanged:root.change('echoCancellation',checked);}
    HifiControlsUit.Switch {id:noiseControl;width:switchWidth;height:44;switchWidth:40;labelTextOn:'Noise Suppression';checked:root.browserState.settings.noiseSuppression===true;enabled:root.browserReady&&!root.awaiting&&root.browserState.controls.noiseSuppression;onCheckedChanged:root.change('noiseSuppression',checked);}
    HifiControlsUit.Switch {id:agcControl;width:switchWidth;height:44;switchWidth:40;labelTextOn:'Automatic Gain Control';checked:root.browserState.settings.autoGainControl===true;enabled:root.browserReady&&!root.awaiting&&root.browserState.controls.autoGainControl;onCheckedChanged:root.change('autoGainControl',checked);}
    Text{color:'white';text:'Capture gain: '+(root.browserState.settings.inputGainPercent===null?'unavailable':root.browserState.settings.inputGainPercent+'%')}
    Slider{id:gainControl;palette.dark:enabled?'#00b4ef':'#686868';width:parent.width;from:0;to:200;stepSize:1;value:root.browserState.settings.inputGainPercent===null?100:root.browserState.settings.inputGainPercent;enabled:root.browserReady&&!root.awaiting&&root.browserState.controls.inputGainPercent;onMoved:if(!pressed)root.change('inputGainPercent',Math.round(value));onPressedChanged:if(!pressed)root.change('inputGainPercent',Math.round(value));}
    Text{width:parent.width;wrapMode:Text.Wrap;color:'#cccccc';text:'Unsupported processing is disabled. Device labels stay in your browser; this page does not request microphone permission.'}
   }}
  }
 }
 Timer{interval:500;repeat:true;running:tabs.currentIndex===1&&!root.browserReady&&!root.awaiting;onTriggered:root.sendToScript({type:'browserCaptureReady',epoch:root.browserUiEpoch});}
}
